(ns maelstrom.core-test
  (:require [clojure.test :refer :all]
            [maelstrom.core :refer :all]))

